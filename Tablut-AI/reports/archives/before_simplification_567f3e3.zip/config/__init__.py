"""Tablut project package."""

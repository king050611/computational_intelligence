"""Read-only analysis for the 2026-11-25 experiment; no game or training changes."""
import collections, hashlib, json, math
from pathlib import Path
from random import Random

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]

def paired_summary(data):
    pairs = collections.defaultdict(list)
    for row in data['results']:
        points = 1 if row['winner'] == 'DRAW' else 2 if row['winner'] == row['our_side'] else 0
        pairs[row['opening_id']].append((row['our_side'], points))
    assert all(len(rows)==2 and {r[0] for r in rows}=={'A','D'} for rows in pairs.values())
    scores=[sum(r[1] for r in rows)/4 for rows in pairs.values()]
    rng=Random(42); n=len(scores)
    dist=sorted(sum(rng.choices(scores,k=n))/n for _ in range(10000))
    return {'pairs':n,'point_rate':sum(scores)/n,'ci95':[dist[250],dist[9750]],'bootstrap_seed':42,'bootstrap_samples':10000,'pair_scores':dict(zip(pairs,scores))}

def read_rounds():
    rounds=[]
    for p in sorted((HERE/'formal').glob('checkpoint-*.json')):
        d=json.loads(p.read_text()); samples=d['replay_batches'][-1] if d['replay_batches'] else []
        replay=[x for batch in d['replay_batches'] for x in batch]
        weights=d['candidate']['weights']
        errors=[(sum(w*x for w,x in zip(weights,row[:4]))-row[-1])**2 for row in replay] if weights else []
        rounds.append({'generation':d['generation'],'candidate':d['candidate']['evaluation'],'best_generation':d['best']['generation'],'best_points':d['best']['evaluation']['overall']['points'],'weights':weights,'training_outcomes':d['training_outcomes'],'new_samples':len(samples),'rolling_samples':len(replay),'batch_labels':dict(collections.Counter(row[-1] for row in samples)),'rolling_labels':dict(collections.Counter(row[-1] for row in replay)),'rolling_fit_mse':sum(errors)/len(errors) if errors else None,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    return rounds

if __name__=='__main__':
    results={'rounds':read_rounds(),'experiments':{}}
    experiment=ROOT/'reports/experiments/linear_v1_20261125'
    for p in experiment.glob('*.json'):
        d=json.loads(p.read_text())
        if 'results' not in d:continue
        results['experiments'][p.stem]={'standings':d['standings'],'paired':paired_summary(d),'issues':{k:sum(r[k] for r in d['results']) for k in ('illegal_moves','timeouts','exceptions')},'max_player_seconds':max(max(r['attacker_seconds'],r['defender_seconds']) for r in d['results']),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    (HERE/'analysis.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Analyzed',len(results['rounds']),'checkpoints;',len(results['experiments']),'experiments')

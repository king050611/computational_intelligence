from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from evaluate_run import run,HERE,EXP
from analyze_run import paired_summary

if __name__=='__main__':
    policy=json.loads((HERE/'execution_policy.json').read_text())
    results=[]
    for config in policy['dynamic_ablations']:
        name=config['id']
        args=['scripts/run_experiments.py','--strategy','enhanced_dynamic','--opponent','adaptive','--openings',EXP/'selection_openings.json','--max-depth',config['max_depth'],'--tt-capacity',config['tt_capacity'],'--output',EXP/(name+'.json')]
        if not config['ordering']:args+=['--no-ordering']
        run(name,args)
        stats=paired_summary(json.loads((EXP/(name+'.json')).read_text()))
        results.append({'config':config,'paired':stats})
        (HERE/'dynamic_selection.json').write_text(json.dumps(results,indent=2))
    chosen=max(results,key=lambda row:(row['paired']['point_rate'],-row['config']['max_depth'],-row['config']['tt_capacity'],row['config']['ordering']))
    (HERE/'frozen_dynamic.json').write_text(json.dumps({'chosen':chosen,'rule':'Highest selection point rate; ties prefer shallower depth, smaller hint table, then ordering. Holdout never used for selection.'},indent=2))
    config=chosen['config']
    args=['scripts/run_experiments.py','--strategy','enhanced_dynamic','--opponent','adaptive','--openings',EXP/'final_holdout.json','--max-depth',config['max_depth'],'--tt-capacity',config['tt_capacity'],'--output',EXP/'dynamic_holdout.json']
    if not config['ordering']:args+=['--no-ordering']
    run('dynamic_holdout',args)
    print('DYNAMIC_SUITE_COMPLETE',flush=True)

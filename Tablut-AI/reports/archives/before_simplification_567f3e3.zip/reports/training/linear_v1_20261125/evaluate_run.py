"""Operational evaluation runner for this experiment; uses existing project CLIs."""
from pathlib import Path
import datetime,json,subprocess,sys,time
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
EXP=ROOT/'reports/experiments/linear_v1_20261125'
MANIFEST=HERE/'evaluation_manifest.json'

def run(name,args):
    manifest=json.loads(MANIFEST.read_text()) if MANIFEST.exists() else {'commands':[]}
    command=[sys.executable,'-u',*map(str,args)]
    print('START',name,flush=True); start=time.perf_counter()
    with (HERE/(name+'.log')).open('x',encoding='utf-8') as log:
        result=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    manifest['commands'].append({'name':name,'argv':command,'seconds':time.perf_counter()-start,'returncode':result.returncode,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    MANIFEST.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print('END',name,result.returncode,round(manifest['commands'][-1]['seconds'],1),flush=True)
    if result.returncode:
        print((HERE/(name+'.log')).read_text(),flush=True)
        raise RuntimeError(name+' failed')

def benchmark(name,model,opponent,*,candidate=False,openings='selection_openings.json',extra=()):
    args=['scripts/benchmark.py','--strategy','minimax','--model',model,'--opponent',opponent,'--openings',EXP/openings,'--output',EXP/(name+'.json')]
    if candidate: args+=['--candidate']
    run(name,args+list(extra))

if __name__=='__main__':
    model=HERE/'formal/checkpoint-0010.json'
    assert model.exists(),'Training must complete first'
    benchmark('candidate10_vs_minimax',model,'minimax',candidate=True)
    benchmark('best10_vs_adaptive',model,'adaptive')
    benchmark('candidate10_vs_dynamic',model,'enhanced_dynamic',candidate=True)
    benchmark('best10_vs_minimax',model,'minimax')
    print('STAGE_VALIDATION_COMPLETE',flush=True)
